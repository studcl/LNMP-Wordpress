#ifdef PHP_WIN32
#include "../../../../main/config.w32.h"
#else
#include <php_config.h>
#endif
